<footer class="adminuiux-footer mt-auto">
    <div class="container-fluid text-center">
        <span class="small">Copyright @2025 Ratna Cellular And Collections</span>
    </div>
</footer>